/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   processTestCode.h
 * Author: Gerstl
 *
 * Created on February 26, 2023, 1:05 PM
 */

#ifndef PROCESSTESTCODE_H
#define PROCESSTESTCODE_H

#ifdef __cplusplus
extern "C" {
#endif


int processTestOne();
int processTestTwo();
int processTestThree();


#ifdef __cplusplus
}
#endif

#endif /* PROCESSTESTCODE_H */

